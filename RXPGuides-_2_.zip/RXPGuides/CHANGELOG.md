# RXP Guides

## [v4.2.11](https://github.com/RestedXP/RXPGuides/tree/v4.2.11) (2022-09-03)
[Full Changelog](https://github.com/RestedXP/RXPGuides/compare/v4.2.10...v4.2.11) [Previous Releases](https://github.com/RestedXP/RXPGuides/releases)

- Fix lua error for non-(enUS|zhCN) locales  
- Improve zhCN step grammar  
- Remove BCC builds (#49)  
